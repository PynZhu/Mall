package com.mall.backend.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mall.backend.mapper.UserMapper;
import com.mall.backend.model.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

@Service
public class UserService extends ServiceImpl<UserMapper, User> {
    public User getUserByUsername(String username) {
        return baseMapper.selectByUsername(username);
    }

    public boolean registerUser(User user) {
        // 检查用户是否已存在
        User existingUser = getUserByUsername(user.getUsername());
        if (existingUser != null) {
            return false;
        }

        // 密码加密
        user.setPassword(encryptPassword(user.getPassword()));

        // 保存用户
        return save(user);
    }

    public User login(String username, String password) {
        // 查询用户
        User user = getUserByUsername(username);

        // 验证密码
        if (user != null && user.getPassword().equals(encryptPassword(password))) {
            return user;
        }

        return null;
    }

    public boolean updateUser(User user) {
        // 如果更新密码，需要加密
        if (user.getPassword() != null) {
            user.setPassword(encryptPassword(user.getPassword()));
        }

        return updateById(user);
    }

    // 简单的密码加密方法
    private String encryptPassword(String password) {
        return DigestUtils.md5DigestAsHex(password.getBytes());
    }
}