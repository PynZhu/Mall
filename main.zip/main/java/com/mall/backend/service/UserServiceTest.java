package com.mall.backend.service;

import com.mall.backend.model.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @Test
    public void testRegisterUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password123");
        user.setEmail("test@example.com");

        boolean result = userService.registerUser(user);

        assertTrue(result);
        assertNotNull(user.getId());
    }

    @Test
    public void testDuplicateUserRegistration() {
        User user = new User();
        user.setUsername("existuser");
        user.setPassword("password123");
        user.setEmail("exist@example.com");

        // 先注册一个用户
        userService.registerUser(user);

        // 尝试注册相同用户名的用户
        User duplicateUser = new User();
        duplicateUser.setUsername("existuser");
        duplicateUser.setPassword("anotherpassword");

        boolean result = userService.registerUser(duplicateUser);

        assertFalse(result);
    }
}

